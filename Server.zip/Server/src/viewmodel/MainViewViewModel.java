package viewmodel;

import javafx.scene.control.ListView;
import model.Model;
import model.Offer;
import model.User;

import java.rmi.RemoteException;

public class MainViewViewModel {
    private Model model;


    public MainViewViewModel(Model model){
        this.model=model;
    }

    public String addOffer(Offer offer) throws RemoteException {
        return this.model.addOffer(offer);
    }

    public void login(String username,String password) throws RemoteException {
        model.login(username, password);
    }


    public String signUp(User user) throws RemoteException {
        return model.signUp(user);
    }
}
