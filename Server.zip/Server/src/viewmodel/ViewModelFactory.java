package viewmodel;

import com.sun.tools.javac.Main;
import model.Model;

public class ViewModelFactory {
    private MainViewViewModel mainViewViewModel;

    public ViewModelFactory(Model model){
        this.mainViewViewModel=new MainViewViewModel(model);
    }

    public MainViewViewModel getMainViewViewModel() {
        return mainViewViewModel;
    }
}
