package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class OnlineUserList {
    private static OnlineUserList instance;
    private ObservableList<User> users;


    private OnlineUserList(){
        this.users= FXCollections.observableArrayList();
    }

    public static OnlineUserList getInstance(){
        if(instance==null)
            instance=new OnlineUserList();
        return instance;
    }

    public void loginInUser(String username,String password){
        for(User user:users){
            if(user.forLogin(username, password))
                users.add(user);
        }
    }

    public ObservableList<String> getUsersString() {
        ObservableList<String> observableList=FXCollections.observableArrayList();
        for(User user:users)
            observableList.add(user.toStringShort());
        return observableList;
    }

    public User getUserByUsername(String username){
        for(User user:users){
            if (user.getUsername().equals(username))
                return user;
        }
        return null;
    }
}
