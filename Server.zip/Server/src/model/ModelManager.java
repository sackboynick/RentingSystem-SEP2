package model;

public class ModelManager implements Model{
    public ModelManager(){

    }

    @Override
    public String addOffer(Offer offer) {
        return OfferList.getInstance().addOffer(offer);
    }

    @Override
    public void login(String username, String password) {
        OnlineUserList.getInstance().loginInUser(username,password);
    }

    @Override
    public String signUp(User user) {
        return UserList.getInstance().addUser(user);
    }


}
