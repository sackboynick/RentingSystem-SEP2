package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class OfferList {
    private static OfferList instance;
    private ObservableList<Offer> offers;


    private OfferList(){
        this.offers= FXCollections.observableArrayList();
    }

    public static OfferList getInstance(){
        if(instance==null)
            instance=new OfferList();
        return instance;
    }

    public String addOffer(Offer offer){
        if(!offers.contains(offer)) {
            offers.add(offer);
            return "Offer #"+offer.getID()+" has been added!";
        }
        return "There has been a problem adding the offer";
    }
    public String removeOffer(String ID){
        for(Offer offer: offers){
            if (offer.getID().equals(ID)) {
                offers.remove(offer);
                return "Offer #"+offer.getID()+" has been removed!";
            }

        }
        return "There has been a problem removing the offer";
    }

    public Offer getOfferByID(String ID) {
        for(Offer offer:offers){
            if(offer.getID().equals(ID))
                return offer;
        }
        return null;
    }

    public void sortListByPrice(){
        ObservableList<Offer> offersCopy=FXCollections.observableArrayList();
        double lastPrice=0;
        for(Offer offer: offers){
            if(offer.getPricePerMonth()>lastPrice){
                offersCopy.add(offer);
                lastPrice=offer.getPricePerMonth();
            }
            else{
                offersCopy.add(0,offer);
            }
        }
    }

    public ObservableList<Offer> getOffers() {
        return offers;
    }

    public ObservableList<String> getOffersString(){
        ObservableList<String> observableList=FXCollections.observableArrayList();
        for(Offer offer:offers)
            observableList.add(offer.getTitle()+" "+offer.getPricePerMonth());
        return observableList;
    }
}
