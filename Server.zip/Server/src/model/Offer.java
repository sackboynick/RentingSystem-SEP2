package model;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Random;
import java.util.Date;


public class Offer implements Serializable {
    private String ID, title, subDescription, description, additionalInformation, location;
    private static final String[] TYPE = {"Apartment", "House","Room"};
    private int ageMinimum, peopleAllowedNumber, roomsNumber, numberOfOtherPeople, noOfFlats;
    private double pricePerMonth, deposit;
    private Date availableDate;
    private static final String[] FEATURES = {"Wi-Fi", "Pets", "Smoking", "Swimming pool"};

    private ArrayList<String> featuresList;

    public Offer(String title, String description, int pricePerMonth, String type, String location) {
        Random rand = new Random();
        DecimalFormat decimalFormat = new DecimalFormat("000000");
        setID(decimalFormat.format(Integer.toString(rand.nextInt(1000000))));
        setTitle(title);
        setDescription(description);
        setPricePerMonth(pricePerMonth);
        setLocation(location);
        this.availableDate=new Date();
        this.featuresList = new ArrayList<>();
    }


    private void getAvailableDate(Date date) {
        this.availableDate = date;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setSubDescription(String subDescription) {
        this.subDescription = subDescription;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setAdditionalInformation(String additionalInformation) {
        this.additionalInformation = additionalInformation;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setAgeMinimum(int ageMinimum) {
        this.ageMinimum = ageMinimum;
    }

    public void setPeopleAllowedNumber(int peopleAllowedNumber) {
        this.peopleAllowedNumber = peopleAllowedNumber;
    }

    public void setRoomsNumber(int roomsNumber) {
        this.roomsNumber = roomsNumber;
    }

    public void setNumberOfOtherPeople(int numberOfOtherPeople) {
        this.numberOfOtherPeople = numberOfOtherPeople;
    }

    public void setPricePerMonth(double pricePerMonth) {
        this.pricePerMonth = pricePerMonth;
    }

    public void setDeposit(double deposit) {
        this.deposit = deposit;
    }

    public String getID() {
        return ID;
    }

    public String getTitle() {
        return title;
    }

    public String getSubDescription() {
        return subDescription;
    }

    public String getDescription() {
        return description;
    }

    public String getAdditionalInformation() {
        return additionalInformation;
    }

    public String[] getAllTypes() {
        return TYPE;
    }

    public String getLocation() {
        return location;
    }

    public int getAgeMinimum() {
        return ageMinimum;
    }

    public int getPeopleAllowedNumber() {
        return peopleAllowedNumber;
    }

    public int getRoomsNumber() {
        return roomsNumber;
    }

    public int getNumberOfOtherPeople() {
        return numberOfOtherPeople;
    }

    public double getPricePerMonth() {
        return pricePerMonth;
    }

    public double getDeposit() {
        return deposit;
    }

    public ArrayList<String> getFeaturesList() {
        return featuresList;
    }


    public String addFeature(String feature) {
        if (!featuresList.contains(feature)) {
            featuresList.add(feature);
            return feature + " added!";
        }
        return "Problem while adding the feature";
    }

    public String removeFeature(String feature) {
        if (featuresList.contains(feature)) {
            featuresList.remove(feature);
            return feature + " removed.";
        }
        return "Problem while removing the feature";
    }


}
