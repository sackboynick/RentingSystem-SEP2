package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class UserList {
    private static UserList instance;
    private ObservableList<User> users;


    private UserList(){
        this.users= FXCollections.observableArrayList();
    }

    public static UserList getInstance(){
        if(instance==null)
            instance=new UserList();
        return instance;
    }

    public ObservableList<String> getUsers() {
        ObservableList<String> observableList=FXCollections.observableArrayList();
        for(User user:users)
            observableList.add(user.toStringShort());
        return observableList;
    }

    public String addUser(User user){
        for(User user1:users){
            if(user1.getUsername().equals(user.getUsername()))
                return "This username already exists";
        }
        users.add(user);
        return "You signed in!";
    }
    public User getUserByUsername(String username){
        for(User user:users){
            if (user.getUsername().equals(username))
                return user;
        }
        return null;
    }
}
