package model;

import java.rmi.RemoteException;

public interface Model {
    String addOffer(Offer offer);
    void login(String username,String password);
    String signUp(User user);

}
