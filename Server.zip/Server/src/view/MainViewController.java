package view;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import model.OfferList;
import model.OnlineUserList;
import model.RentingList;

public class MainViewController extends ViewController{
    @FXML
    private ListView<String> onlineUsersList,offersList,dealsList;
    @FXML private Label messageStatus;

    public MainViewController(){

    }

    @Override
    protected void init(){
        this.onlineUsersList.setItems(OnlineUserList.getInstance().getUsersString());
        this.offersList.setItems(OfferList.getInstance().getOffersString());
        this.dealsList.setItems(RentingList.getInstance().getRentingsString());
        this.messageStatus.setText("");
    }

    public void reset(){

    }

    @FXML
    public void openUserInterface(){
        String username=this.onlineUsersList.getSelectionModel().getSelectedItem();
        getViewHandler().openView("userInterface");
    }

}
