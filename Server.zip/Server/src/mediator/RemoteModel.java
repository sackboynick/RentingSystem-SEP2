package mediator;

import model.Offer;
import model.User;
import utility.observer.subject.RemoteSubject;

import java.rmi.RemoteException;

public interface RemoteModel extends RemoteSubject<String,Offer>{
    String addOffer(Offer offer) throws RemoteException;
    void login(String username,String password) throws RemoteException;
    String signUp(User user) throws RemoteException;
}
