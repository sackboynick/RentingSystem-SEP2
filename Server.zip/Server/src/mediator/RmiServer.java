package mediator;

import model.Model;
import model.Offer;
import model.OfferList;
import model.User;
import utility.NamedPropertyChangeSubject;
import utility.observer.listener.GeneralListener;
import utility.observer.subject.PropertyChangeHandler;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.rmi.RemoteException;

public class RmiServer implements RemoteModel, NamedPropertyChangeSubject {
    private utility.observer.subject.PropertyChangeHandler<String,Offer> propertyChangeHandler;
    private PropertyChangeSupport propertyChangeSupport;
    private int usersOnline;
    private Model model;

    public RmiServer(Model model){
        this.propertyChangeHandler=new PropertyChangeHandler<String, Offer>(this,true);
        this.propertyChangeSupport=new PropertyChangeSupport(this);
        this.usersOnline=0;
        this.model=model;
    }


    @Override
    public String addOffer(Offer offer) throws RemoteException {
        return this.model.addOffer(offer);
    }

    @Override
    public void login(String username,String password) throws RemoteException {
        model.login(username, password);
    }

    @Override
    public String signUp(User user) throws RemoteException {
        return model.signUp(user);
    }


    @Override
    public void addListener(String propertyName, PropertyChangeListener listener) {
        this.propertyChangeSupport.addPropertyChangeListener(propertyName, listener);
    }

    @Override
    public void removeListener(String propertyName, PropertyChangeListener listener) {
        this.propertyChangeSupport.removePropertyChangeListener(propertyName, listener);
    }

    @Override
    public boolean addListener(GeneralListener<String, Offer> listener, String... propertyNames) throws RemoteException {
        return this.propertyChangeHandler.addListener(listener, propertyNames);
    }

    @Override
    public boolean removeListener(GeneralListener<String, Offer> listener, String... propertyNames) throws RemoteException {
        return this.propertyChangeHandler.removeListener(listener, propertyNames);
    }
}
